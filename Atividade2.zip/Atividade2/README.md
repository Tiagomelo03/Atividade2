# lowdb

Ficheiro README para a atividade 2.
Feito pelo aluno Tiago Melo nº28242

* `indez.js` código para iniciar servidor com lowdb 

* `routes/Userroutes.js`código que contém as routes para o servidor

* `public/.js` codigo que contem o index.html que é a pagina principal, doc.html e about.html.

* `students.json` codigo que contem os dados dos estudantes.


