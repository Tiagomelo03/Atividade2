import express from 'express';
import { getStudents, getStudentById, addStudent, updateStudent, deleteStudent } from './lowdb.js';

const app = express();
const port = 3000;

app.use(express.json());
app.use(express.static('public/'));

// Rotas usando as funções do lowdb.js
app.get('/students', async (req, res) => {
  const students = await getStudents();
  res.json(students);
});

app.get('/students/:id', async (req, res) => {
  const student = await getStudentById(Number(req.params.id));
  if (student) {
    res.json(student);
  } else {
    res.status(404).send('Estudante não encontrado');
  }
});

app.post('/students', async (req, res) => {
  const { name, age, study } = req.body;
  if (!name || !age || !study) {
    return res.status(400).send('Campos "name", "age" e "study" são obrigatórios');
  }
  const newStudent = await addStudent(name, age, study);
  res.status(201).json(newStudent);
});

app.put('/students/:id', async (req, res) => {
  const { name, age, study } = req.body;
  const updatedStudent = await updateStudent(Number(req.params.id), { name, age, study });
  if (updatedStudent) {
    res.json(updatedStudent);
  } else {
    res.status(404).send('Estudante não encontrado');
  }
});

app.delete('/students/:id', async (req, res) => {
  const success = await deleteStudent(Number(req.params.id));
  if (success) {
    res.status(204).send();
  } else {
    res.status(404).send('Estudante não encontrado');
  }
});

app.listen(port, () => {
  console.log(`Servidor rodando em http://localhost:${port}`);
});
