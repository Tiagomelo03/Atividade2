import { JSONFilePreset } from 'lowdb/node';

const defaultData = { users: [] }
const db = await JSONFilePreset('students.json', defaultData)

async function initDB() {
  await db.read();  // Tenta ler o arquivo JSON

  // Se o arquivo estiver vazio ou não existir, inicializa com os dados padrão
  if (!db.data) {
    db.data = defaultData;
    await db.write();  // Escreve os dados no arquivo
    console.log("Arquivo JSON estava vazio ou não existia, dados padrão foram escritos.");
  }

  // Exibe os dados atuais para depuração
  console.log("Conteúdo atual do banco de dados:", db.data);
}

await initDB();

// Funções CRUD para estudantes

// Adiciona um estudante
export async function addStudent(name, age, study) {
  await db.read();
  const newId = db.data.students.length > 0 ? db.data.students[db.data.students.length - 1].id + 1 : 1;
  const newStudent = { id: newId, name, age, study };
  db.data.students.push(newStudent);
  await db.write();
  return newStudent;
}

// Retorna todos os estudantes
export async function getStudents() {
  await db.read();
  return db.data.students;
}

// Retorna um estudante específico por ID
export async function getStudentById(id) {
  await db.read();
  return db.data.students.find((student) => student.id === parseInt(id));  // Garantindo que o id seja tratado como número
}

// Atualiza um estudante
export async function updateStudent(id, updatedData) {
  await db.read();
  const student = db.data.students.find((s) => s.id === parseInt(id));  // Garantindo que o id seja tratado como número
  if (student) {
    Object.assign(student, updatedData);
    await db.write();
    return student;
  }
  return null;
}

// Deleta um estudante
export async function deleteStudent(id) {
  await db.read();
  const index = db.data.students.findIndex((student) => student.id === parseInt(id));  // Garantindo que o id seja tratado como número
  if (index !== -1) {
    db.data.students.splice(index, 1);
    await db.write();
    return true;
  }
  return false;
}
