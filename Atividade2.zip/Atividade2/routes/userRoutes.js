import { JSONFilePreset } from 'lowdb/node';
const express = require('express');
const { Low, JSONFile } = require('lowdb');
const path = require('path');
const router = express.Router();

// Caminho para o arquivo JSON onde os dados serão armazenados
const dbFilePath = path.join(__dirname, '../students.json');

// Configuração do lowdb
const adapter = new JSONFile(dbFilePath);
const db = new Low(adapter);

// Inicializar o banco de dados com dados padrão se o arquivo estiver vazio
async function initDB() {
  await db.read();
  db.data ||= { students: [] }; // Se o arquivo estiver vazio, inicializa com um array vazio
  await db.write();
}

// Função para validar os dados do estudante
const validateStudentData = (data) => {
  const { name, course, year } = data;
  if (!name || !course || !year) {
    return 'Os campos "name", "course" e "year" são obrigatórios.';
  }
  return null; // Dados válidos
};

// Rota GET /students - Retorna todos os estudantes
router.get('/', async (req, res) => {
  await db.read(); // Ler o arquivo de dados
  res.json(db.data.students);
});

// Rota GET /students/:id - Retorna um estudante específico por ID
router.get('/:id', async (req, res) => {
  await db.read(); // Ler o arquivo de dados
  const student = db.data.students.find(s => s.id === req.params.id);
  if (!student) {
    return res.status(404).send('Estudante não encontrado');
  }
  res.json(student);
});

// Rota POST /students - Cria um novo estudante
router.post('/', async (req, res) => {
  const { name, course, year } = req.body;

  // Validação dos dados
  const validationError = validateStudentData(req.body);
  if (validationError) {
    return res.status(400).send(validationError); // Bad Request
  }

  await db.read(); // Ler o arquivo de dados
  const id = (db.data.students.length + 1).toString(); // Gerar ID único
  const newStudent = { id, name, course, year };
  db.data.students.push(newStudent);

  // Salvar os estudantes no arquivo JSON
  await db.write();

  res.status(201).json(newStudent); // Created
});

// Rota PUT /students/:id - Atualiza os dados de um estudante existente
router.put('/:id', async (req, res) => {
  const students = db.data.students;
  const student = students.find(s => s.id === req.params.id);
  if (!student) {
    return res.status(404).send('Estudante não encontrado');
  }

  const { name, course, year } = req.body;

  // Validação dos dados
  const validationError = validateStudentData(req.body);
  if (validationError) {
    return res.status(400).send(validationError); // Bad Request
  }

  // Atualizar os dados do estudante
  student.name = name || student.name;
  student.course = course || student.course;
  student.year = year || student.year;

  // Salvar os estudantes no arquivo JSON
  await db.write();

  res.json(student); // OK
});

// Rota DELETE /students/:id - Remove um estudante específico
router.delete('/:id', async (req, res) => {
  const studentIndex = db.data.students.findIndex(s => s.id === req.params.id);
  if (studentIndex === -1) {
    return res.status(404).send('Estudante não encontrado');
  }

  db.data.students.splice(studentIndex, 1);

  // Salvar os estudantes no arquivo JSON
  await db.write();

  res.status(204).send(); // No Content
});

// Inicializar o banco de dados ao iniciar o servidor
initDB();

module.exports = router;
